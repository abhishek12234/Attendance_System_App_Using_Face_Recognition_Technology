from tkinter import *
from tkinter import ttk
from PIL import Image,ImageTk,ImageDraw
import cv2
import face_recognition
import pandas as pd
import os
from datetime import datetime, timedelta
from itertools import groupby
import time
from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.models import load_model
import numpy as np
import calendar
from tkcalendar import DateEntry
from datetime import date
def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)
month_nam=list(calendar.month_name)
current_month=month_nam[datetime.now().month]

print()
change=""
face_cascade = cv2.CascadeClassifier(resource_path("newfacedectect1.xml"))




def create_excel():
    year= 2023

    
    for month in range(1,13):
    
        if ((month==2) and ((year%4==0) or ((year%100==0) and (year%400==0)))):
            (pd.DataFrame({**{"ID":[]},**{"professor":[]},**{f"{str(i).zfill(2)}-{str(month).zfill(2)}-{year}":[] for i in range(1,29+1)}})).to_excel(r"C:\Users\hp\OneDrive\Desktop\major_project\data\\"+month_nam[month]+".xlsx",index=False)
        elif month==2:
            (pd.DataFrame({**{"ID":[]},**{"professor":[]},**{f"{str(i).zfill(2)}-{str(month).zfill(2)}-{year}":[] for i in range(1,28+1)}})).to_excel(r"C:\Users\hp\OneDrive\Desktop\major_project\data\\"+month_nam[month]+".xlsx",index=False)
        elif month in [1,3,5,7,8,10,12]:
            (pd.DataFrame({**{"ID":[]},**{"professor":[]},**{f"{str(i).zfill(2)}-{str(month).zfill(2)}-{year}":[] for i in range(1,31+1)}})).to_excel(r"C:\Users\hp\OneDrive\Desktop\major_project\data\\"+month_nam[month]+".xlsx",index=False)
        else:
            (pd.DataFrame({**{"ID":[]},**{"professor":[]},**{f"{str(i).zfill(2)}-{str(month).zfill(2)}-{year}":[] for i in range(1,30+1)}})).to_excel(r"C:\Users\hp\OneDrive\Desktop\major_project\data\\"+month_nam[month]+".xlsx",index=False)

class stop:
    def __init__(self):
        self.c=1
        self.l=[]
    def timer(self):
        
       k=int(time.ctime().split()[-2].split(":")[-1][-1])
       self.l.append(k)
       
       if len(self.l)>=2:
    
        if self.l[-1]!=self.l[-2]:
    
            self.l=self.l[-2:]
        
            self.c+=1
       #h=(g>=self.c)
       
       return self.c

win=Tk()
win.geometry("500x400")
win.minsize(500,400)

# set maximum window size value
win.maxsize(500, 400)
win.title("gui")
lis=[]

n=[]
z=[]
g=0
model1=load_model(resource_path('UI\liveness.model'))
def face_use():
   
    global path
    global known_face_encod
    global known_face_name
    global photo
   
    path=resource_path("images")
    photo=[resource_path("images")+"\\"+i for i in os.listdir(path)]
    print(photo)
    
    known_face_encod=[face_recognition.face_encodings(face_recognition.load_image_file(i))[0] for i in photo]
    known_face_name=[i[:i.index(".")] for i in os.listdir(path)]
    print(known_face_name)
    return path,known_face_encod,known_face_name,photo

def fake(fram):
    
        try:
            global spoof
            fak=["real","fake"]
            # preprocessing for gender detection model
            face_cr = cv2.resize(fram, (32,32))
            face_cr = face_cr.astype("float") / 255.0
            face_cr = img_to_array(face_cr)
            face_cr = np.expand_dims(face_cr, axis=0)

            # apply gender detection on face
            conf1 = model1.predict(face_cr)[0] # model.predict return a 2D matrix, ex: [[9.9993384e-01 7.4850512e-05]]

            # get label with max accuracy
            idx1 = np.argmax(conf1)
            spoof=fak[idx1]
            print("__________________________++++++++++++")
            return spoof
        except:pass
    
def clear():
    
    
    def options1():
        
        def back2():
            button2.destroy()
            button3.destroy()
            button4.destroy()
            button7.destroy()
            background_lable13.destroy()
            
            clear()
        def get_details():

            background_lable13.destroy()
            button2.destroy()
            button3.destroy()
            button4.destroy()
            button7.destroy()

            filename_get_details=PhotoImage(file=resource_path("UI\details.png"))
            get_details_label=Label(win,image=filename_get_details)
            get_details_label.place(x=0,y=0)

            df3=pd.read_excel(resource_path("data")+"\\"+current_month+".xlsx")
            lst1=list(df3.professor)

            def srch1(event):
                valuee=event.widget.get()
                print(valuee)
                if valuee=="":
                    Entry1["values"]=lst1
                else:
                    data=[]
                    for item in lst1[1:]:
                        if valuee.lower() in item.lower():
                            data.append(item)
                    Entry1["values"]=data
            

            def back_get_details():
                
                detail_button1.destroy()
                detail_button2.destroy()
                get_details_label.destroy()
                first_date.destroy()
                second_date.destroy()
                
                options1()
                
            def detail_function():
                present_count=0
                start_year,start_month,start_day=map(int,str(first_date.get_date()).split("-"))
                end_year,end_month,end_day=map(int,str(second_date.get_date()).split("-"))

                if start_year !=2023 or end_year!=2023:
                    
                    get_details_label1.config(text="plz select current year")
                elif Entry1.get() not in lst1:
                    
                    get_details_label1.config(text="This name is not registersed")
                else:
                
                    start=datetime(start_year,start_month,start_day)
                    end=datetime(end_year,end_month,end_day)
                    
                    rangee=pd.date_range(start,(end-timedelta(days=1)),freq="d")
                    
                    date_list=list(map(lambda x:"-".join((x[:x.index(" ")].split("-"))[::-1]),list(map(str,list(rangee)))))
                    month_list=list(map(lambda x:x.split("-")[1],date_list))
                    print(date_list)

                    for i,j in groupby(date_list,key=lambda x:x.split("-")[1]):
                            print(i,j)
                            df_dates=pd.read_excel(resource_path("data")+"\\" + month_nam[int(i)]+".xlsx")
                            
                            for e in list(j):
                                if len(str(df_dates.loc[lst1.index(Entry1.get()),e]))==5:
                                    present_count+=1
                    get_details_label1.config(text="Total Number Of Days present: "+str(present_count))

                

                
                
                print(start_year,start_month,start_day)
                print(end_year,end_month,end_day)

                
                


            Entry1=ttk.Combobox(win,value=lst1,width=12)
            Entry1.set("Search")
            Entry1.place(relx=0.27,rely=0.21,anchor="center")

            Entry1.bind("<KeyRelease>",srch1)
            
            

            first_date = DateEntry(win,selectmode='day',date_pattern ='d/m/yy')
            first_date.place(relx=0.27,rely=0.5,anchor="center")

            second_date = DateEntry(win,selectmode='day',date_pattern ='d/m/yy')
            second_date.place(relx=0.8,rely=0.5,anchor="center")

            detail_button1=Button(win,text="Get Details",bg="#3158d9",fg="#f6f7fb",width=8,command=detail_function)
            detail_button1.place(relx=0.3,rely=0.7,anchor="center")

            detail_button2=Button(win, text = "Back",bg="#3158d9",fg="#f6f7fb",width=8,command = back_get_details)
            detail_button2.place(relx=0.8,rely=0.7,anchor="center")
            


            get_details_label1=Label(win,font=('helvetica',10,),text="",bg="#3158d9",fg="#f6f7fb",borderwidth=0,border=0)
            get_details_label1.place(relx=0.50,rely=0.60,anchor="center")
            
            win.mainloop()
            
        def delete1():
            global df2
            
            background_lable13.destroy()
            button2.destroy()
            button3.destroy()
            button4.destroy()
            button7.destroy()
            
            filename5=PhotoImage(file=resource_path("UI\delete bg.png"))
            background_lable15=Label(win,image=filename5)
            background_lable15.place(x=0,y=0)
            df2=pd.read_excel(resource_path("data")+"\\"+current_month+".xlsx")
            lst=list(df2.professor)

            print(lst)
            
            
                
            def back3():
                background_lable15.destroy()
                combo_box.destroy()
                
                button5.destroy()
                button6.destroy()
                options()
            def srch(event):
                valuee=event.widget.get()
                print(valuee)
                if valuee=="":
                    combo_box["values"]=lst
                else:
                    data=[]
                    for item in lst[1:]:
                        if valuee.lower() in item.lower():
                            data.append(item)
                    combo_box["values"]=data
                        
            def check():
                df2=pd.read_excel(resource_path("data")+"\\"+current_month+".xlsx")
                lst=list(df2.professor)
                l=stop()
                face_use()
                value=combo_box.get()
                print(value)
                if value not in lst:
                    label9.config(text="name not in record")
                    
                else:
                    
                    label8=Label(win)
                    label8.place(relx=0.2,rely=0.2,anchor="center")
                    try:
                      vid2= cv2.VideoCapture(1)
                    except:
                      vid2= cv2.VideoCapture(0)
                    vid2.set(cv2.CAP_PROP_FRAME_WIDTH, 400)
                    vid2.set(cv2.CAP_PROP_FRAME_HEIGHT, 500)
                    button5.config(state="disabled")
                    button6.config(state="disabled")
                    label9.config(text="")
                    path1=resource_path("admin_image")
                    photo1=[resource_path("admin_image")+"\\"+i for i in os.listdir(path1)]
                    print(photo1)
                    
                    known_face_encod1=[face_recognition.face_encodings(face_recognition.load_image_file(i))[0] for i in photo1]
                    known_face_name1=[i[:i.index(".")] for i in os.listdir(path1)]
                    print(known_face_name1,"----")
                    face_use()
                    def check_start():
                        
                            
                      try:   
                        ret,frame2=vid2.read()
                        frame2=cv2.flip(frame2,1)
                            
                        ha2=frame2.copy()
                        frame2=cv2.resize(frame2,(0,0),fx=0.40,fy=0.40)
                            
                        ha2=cv2.resize(ha2,(0,0),fx=0.40,fy=0.40)
                        frame_copy1=ha2.copy()
                        gray = cv2.cvtColor(ha2, cv2.COLOR_BGR2GRAY)
                        face1 = face_cascade.detectMultiScale(gray, 1.3, 5)
                                        
                        rgb_frame1=frame2[:,:,::-1]
                            
                            
                            
                        print("io")
                        print(l.timer())
                      except:pass
                            
                                
                      try:  
                        
                        for x, y, w, h in face1:
                              
                              img1_loc1=face_recognition.face_locations(rgb_frame1)
                              img1_encod1=face_recognition.face_encodings(rgb_frame1,img1_loc1)
                              face_cr1 = frame_copy1[y-5:y+h+5,x-5:x+w+5]
                    # gender dectection
                              q1=fake(face_cr1)
                              cv2.rectangle(frame2,(x,y),(x+w,y+h),(255,255,0),2)
                              for (top,right,bottom,left), face_encoding in zip(img1_loc1,img1_encod1):
                                    match1=face_recognition.compare_faces(known_face_encod1,face_encoding,tolerance=0.5)
                                    
                                    
                                   
                                    #emotion dectection
                                   
                                    name1="Unknown"
                                    if q1=="fake":
                                            
                                          
                                            label9.config(fg="#ff0000")
                                            
                                            label9.config(text="Fake")
                                    else:
                                        label9.config(text="")
                                        if True in match1:
                                            print("iiiiiiiiiiiiiiiiiiiiiiii")
                                            index1=match1.index(True)
                                            name1=known_face_name1[index1]
                                            if name1=="Abhishek":
                                                df4=pd.read_excel(resource_path("deleted_per\suspended.xlsx"))
                                                df4=df4.append({"name":value},ignore_index=True)
                                                df4.to_excel(resource_path("deleted_per\suspended.xlsx"),index=False)
                                                
                                                for i in month_nam[1:]:
                                                    df3=pd.read_excel(resource_path("data")+"\\"+i+".xlsx")
                                                    
                                                    df3=df3.drop(df3.index[lst.index(value)])
                                                    df3.to_excel(resource_path("data")+"\\"+i+".xlsx",index=False)
                                                    
                                                os.remove(resource_path("images")+"\\"+value+".png")
                                                
                                                vid2.release()
                                                label8.destroy()
                                                label9.config(text="Record Successfully Deleted")
                                                button5.config(state="normal")
                                                button6.config(state="normal")
                                                
                                                
                                    
                                        print(name1)
                                        if name1!="Abhishek":
                                                vid2.release()
                                                label8.destroy()
                                                button5.config(state="normal")
                                                button6.config(state="normal")
                                                label9.config(text="You Cannot delete others record")
                                            
                        if l.timer()>6:
                             vid2.release()
                             label8.destroy()
                             button5.config(state="normal")
                             button6.config(state="normal")
                             label9.config(text="Try Again Face was not recognized properly")
                        cv2image= cv2.cvtColor(frame2,cv2.COLOR_BGR2RGB)
                        img1 = Image.fromarray(cv2image)
                            # Convert image to PhotoImage
                        imgtk1 = ImageTk.PhotoImage(image = img1)
                        label8.imgtk1 = imgtk1
                        label8.configure(image=imgtk1)   
                        
                            
                        label8.after(20,check_start)
                        
                        
                    
                        
                      except:pass
                    check_start()    
                        
                    
                
            combo_box=ttk.Combobox(win,value=lst)
            combo_box.set("Search")
            combo_box.place(relx=0.5,rely=0.4,anchor="center")

            combo_box.bind("<KeyRelease>",srch)
            
            button5 = Button(win,font=('Times New Roman',11,'bold'),text="Back",bg="#3158d9",fg="#f6f7fb",width=6,command = back3)
            button5.place(relx=0.7,rely=0.2+0.45,anchor="center")
            
            button6 = Button(win,font=('Times New Roman',11,'bold'),text="Delete",bg="#3158d9",fg="#f6f7fb",width=6,command = check)
            button6.place(relx=0.30,rely=0.2+0.45,anchor="center")
             
            label9=Label(win,font=('helvetica',10,),text="",bg="#3158d9",fg="#f6f7fb",borderwidth=0,border=0)
            label9.place(relx=0.5,rely=0.3+0.2,anchor="center")
            win.mainloop()
            
        
        def Update():
            
                global count
                
                background_lable13.destroy()
                button2.destroy()
                button3.destroy()
                button4.destroy()
                button7.destroy()
                
                
                filename4=PhotoImage(file=resource_path("UI\security (1).png"))
                background_lable14=Label(win,image=filename4)
                background_lable14.place(x=0,y=0)
                count=0
                c=Canvas(win,bg="gray16",height=500,width=500)
                                
                username = "abc" #that's the given username
                password = "cba" #that's the given password

                #username entry
                
                department_entry = Entry(win,width = 35)
                department_entry.place(relx=0.58,rely=0.1+0.26,anchor="center")                                                            
                username_entry = Entry(win,width = 35)
                username_entry.place(relx=0.58,rely=0.2+0.271,anchor="center")
                password_entry = Entry(win, show='*',width=35)
                password_entry.place(relx=0.58,rely=0.3+0.275,anchor="center")
                
                

                #password entry
                def takee():
                     global flag
                     global b2
                     global label1
                     global vid1
                     global flag1
                     global na
                     flag10=0
                     
                     label1 =Label(win)
                     label1.pack()
                     try:
                        vid1=cv2.VideoCapture(1)
                     except:
                        vid1= cv2.VideoCapture(0)
                     vid1.set(cv2.CAP_PROP_FRAME_WIDTH, 400)
                     vid1.set(cv2.CAP_PROP_FRAME_HEIGHT, 500)
                     
                     flag1=1
                     def hit():
                        global flag
                        global flag1
                        global p
                        flag=1
                        flag1=1
                        p=stop()
                        
                        b2.config(state="disabled")
                        print(0000)
                        
                     def takeshot():
                            global change
                            global flag1
                            global p
                            global flag
                            global label1
                            global vid1
                            
                            print(change)
                            _, frame1 = vid1.read()
                            fa=frame1.copy()
                            fa=cv2.resize(fa,(0,0),fx=0.80,fy=0.80)
                            frame1=cv2.flip(frame1,1)
                            image=cv2.cvtColor(frame1,cv2.COLOR_RGB2BGR)
                            gray = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
                            face = face_cascade.detectMultiScale(gray, 1.3, 5)
                            
                            try:      
                                
                                  try:
                                        if flag==1:
                                            cv2.putText(frame1,str(p.timer()),(100,100),cv2.FONT_HERSHEY_DUPLEX,2,(0,0,0),2)
                                            if p.timer()==5:
                                                     
                                                try:
                                                    if flag1==1:
                                                       b2.config(state="normal")
                                                       flag1=0 
                                                      
                                                   
                                                       
                                                    for x, y, w, h in face:
                           
                                                          face_roi = fa[y-80:y+h+80, x-100:x+w+40]    
                                                       
                                                           
               
                                                    flag=0
                                                    cv2.imwrite(resource_path("images")+"\\"+" ".join(list(map(str.capitalize,na.split())))+".png",face_roi)
                                                    b2.destroy()
                                                    
                                                    
                                                    p=stop()
                                                    label1.destroy()
                                                    vid1.release()
                                                    flag10=1
                                                    return
                                                    
                                                    
                                                
                                                   
                                                except:
                                                    
                                                    if flag1==1:
                                                       b2.config(state="normal")
                                                       flag1=0 
                                                    text.set("try again")
                                                    
                                                    
                                                    flag=0
                                                    
                                                    p=stop()
                                  except:pass


                            except:pass
                            cv2image= cv2.cvtColor(frame1,cv2.COLOR_BGR2RGB)
              
                            img = Image.fromarray(cv2image)
                                # Convert image to PhotoImage
                            imgtk = ImageTk.PhotoImage(image = img)
                            label1.imgtk = imgtk
                            label1.configure(image=imgtk)
                              
                              # Repeat after an interval to capture continiously
                
                            print("jskshdks")    
                            label1.after(10, takeshot)
                     
                     takeshot()
                     print("p")
                     text=StringVar()
                     text.set("Click")
                     b2=Button(win,textvariable=text,font=("Helvetica",10,"bold"),bg="#3158d9",fg="#f6f7fb",width=10,command=hit)
                     b2.place(relx=0.5,rely=0.3+0.50,anchor="center")

                


                
                def back1():
            
                        password_entry.destroy()
                        username_entry.destroy()
                          
                       
                        background_lable14.destroy()
                        label2.destroy()
                        
                        
                        button1.destroy()
                        button.destroy()
                       
                      
                        options()
                   

                def trylogin():
                    global na
                    global count
                    #this method is called when the button is pressed
                    #to get what's written inside the entries, I use get()
                    #check if both username and password in the entries are same of the given ones
                  
                    df1=pd.read_excel(resource_path("data")+"\\"+current_month+".xlsx")
                    na=username_entry.get()
                    if username_entry.get()=="" or len(na.strip())==0:
                        label2.config(text="plz enter your name")
                    elif username_entry.get().replace(" ","").isnumeric():
                        label2.config(text="Numerical Values are Not Allowed")
                        
                    elif username_entry.get().capitalize() in list(df1.professor):
                        
                        label2.config(text="name already present")
                        password_entry.delete(0,END)
                    elif  any(list(map(lambda x:int(x in na),'_./][){}^~`(,@#$%^-*+?<>&!"\\'))) or "'" in username_entry.get():
                        label2.config(text="Punctuation marks are not allowed")
                    elif " " not in na.strip():
                         label2.config(text="Atleast give one space between first name and last name")
                        
                        
                    elif password == password_entry.get():
                        print("Correct")
                        
                        if na.capitalize() not in list(df1.professor):
                           
                           print("lll")
                           for i in month_nam[1:]:
                               
                               df1=pd.read_excel(resource_path("data")+"\\"+i+".xlsx")
                               df1=df1.append({"ID":str(len(list(df1.professor))+1).zfill(2),"professor":" ".join(list(map(str.capitalize,na.split())))},ignore_index=True)
                               
                               
                               df1.to_excel(resource_path("data")+"\\"+i+".xlsx",index=False)
                               print(df1)
                        
                        label2.config(text="Your record has been updated")
                        password_entry.delete(0,END)
                        username_entry.delete(0,END)
                        takee()
                        
                        
                                
                    else:
                        print("Wrong")
                        na=""
                        label2.config(text="inncorrect password")
                        password_entry.delete(0,END)
                        count+=1
                        if count==3:
                            back1()
                        
                    return na
                label2=Label(win,font=('helvetica',10,),text="",bg="#3158d9",fg="#f6f7fb",borderwidth=0,border=0)
                label2.place(relx=0.5,rely=0.3+0.35,anchor="center")
                #when you press this button, trylogin is called
                button = Button(win,font=('Times New Roman',11,'bold'),text="Submit",bg="#3158d9",fg="#f6f7fb",width=7, command = trylogin)
                button.place(relx=0.25,rely=0.3+0.5,anchor="center")
                
                button1 = Button(win,font=('Times New Roman',11,'bold'),text="Back",bg="#3158d9",fg="#f6f7fb",width=7,command = back1)
                button1.place(relx=0.75,rely=0.3+0.5,anchor="center")
                

                
                #App starter
                win.mainloop()
        filename3=PhotoImage(file=resource_path("UI\main bg1.png"))
        background_lable13=Label(win,image=filename3)
        background_lable13.place(x=0,y=0)
        
       
        
        button2 = Button(win,font=('Times New Roman',11,'bold'),text="Update",bg="#3158d9",fg="#f6f7fb",width=15,command = Update)
        button2.place(relx=0.50,rely=0.40,anchor="center")

        button3 = Button(win,font=('Times New Roman',11,'bold'),text="Delete",bg="#3158d9",fg="#f6f7fb",width=15,command=delete1)
        button3.place(relx=0.50,rely=0.50,anchor="center")

        button4=Button(win,text="Back",font=('Times New Roman',11,'bold'),bg="#3158d9",fg="#f6f7fb",width=15,command=back2)
        button4.place(relx=0.50,rely=0.70,anchor="center")

        button7= Button(win,font=('Times New Roman',11,'bold'),text="Details",bg="#3158d9",fg="#f6f7fb",width=15,command = get_details)
        button7.place(relx=0.50,rely=0.60,anchor="center")

        

        win.mainloop()
    
    def start():
        global known_face_encod
        global path
        global known_face_name
        global photo
        global flag3
        
        global flag4
        
        global tag5
        global spof
        background_lable1.destroy()
        
        b1.destroy()
        b4.destroy()
        
        
         
        
        
        
        text1=StringVar()
        text1.set("")
        
        text2=StringVar()
        text2.set("")
        
        flag3=1
        flag4=1
        
        
        filename6=PhotoImage(file=resource_path("UI\Attendance.png"))
        background_lable16=Label(win,image=filename6)
        background_lable16.place(x=0,y=0)

        label =Label(win)
        label.place(relx=0.5,rely=0.5,anchor="center")
        
        
        
        try:
            vid= cv2.VideoCapture(1)
        except:
            vid= cv2.VideoCapture(0)
            
        vid.set(cv2.CAP_PROP_FRAME_WIDTH, 400)
        vid.set(cv2.CAP_PROP_FRAME_HEIGHT, 500)
        df=pd.read_excel(resource_path("data")+"\\"+current_month+".xlsx")
        
        vid.set(cv2.CAP_PROP_BUFFERSIZE,1)
       
        unknown=""
        
        tag5=1
        face_use()
        spof=""
        
        def back():
        
            df.to_excel(resource_path("data")+"\\"+current_month+".xlsx",index=False)
            label.destroy()
            vid.release()
           
            b3.destroy()
            
            
            clear()
        
            
        def show_frames():
            global p
            global flag4
            global win
            global flag
            #global b4
            global flag3
            global known_face_encod
            global path
            global known_face_name
            global photo
            global change
            global tag5
            global spof
            
            ret,frame=vid.read()
            frame=cv2.flip(frame,1)
            
                
              
            ha=frame.copy()
                
            frame=cv2.resize(frame,(0,0),fx=0.40,fy=0.40)
                
            ha=cv2.resize(ha,(0,0),fx=0.40,fy=0.40)
            frame_copy=ha.copy()
            gray = cv2.cvtColor(ha, cv2.COLOR_BGR2GRAY)
            face = face_cascade.detectMultiScale(gray, 1.3, 5)
                            
            rgb_frame=frame[:,:,::-1]
            
            
            
           
            tag1=1
            try:
                       
                for x, y, w, h in face:
                    
                    img1_loc=face_recognition.face_locations(rgb_frame)
                    img1_encod=face_recognition.face_encodings(rgb_frame,img1_loc)
                    cv2.rectangle(ha,(x,y),(x+w,y+h),(255,255,0),2)
                    
                    
                    
                    print(img1_loc,img1_encod)
                    
                    face_cr = frame_copy[y-5:y+h+5,x-5:x+w+5]
                        # gender dectection
                    q=fake(face_cr)
                    if q=="fake":
                       cv2.rectangle(ha,(x,y),(x+w,y+h),(0,0,255),2)
                    else:
                        cv2.rectangle(ha,(x,y),(x+w,y+h),(0,255,0),2)
                    
                    for (top,right,bottom,left), face_encoding in zip(img1_loc,img1_encod):
                        match=face_recognition.compare_faces(known_face_encod,face_encoding,tolerance=0.5)
                        #emotion dectection
                        name="Unknown"
                        change=name
                        
                        if True in match:
                            index=match.index(True)
                            name=known_face_name[index]
                            if q=="fake":
                                label3.config(fg="#ff0000")
                                text2.set("Dont Use Photo To Mark Attendence")
                                label5.config(fg="#ff0000")
                                
                            else:
                                label3.config(fg="#f6f7fb")
                                label5.config(fg="#f6f7fb")
                                text2.set("")
                                if name!="Unknown":
                                            
                                        
                                    
                                        if len(str(df.loc[list(df.professor).index(name),datetime.now().strftime("%d-%m-20%y").zfill(10)]))!=5:
                                            df.loc[list(df.professor).index(name),datetime.now().strftime("%d-%m-20%y").zfill(10)]=time.ctime().split()[-2][:-3]
                                            
                                            df.to_excel(resource_path("data")+"\\"+current_month+".xlsx",index=False)
                                          
                                            lis.append(name)
                                        if len(str(df.loc[list(df.professor).index(name),datetime.now().strftime("%d-%m-20%y").zfill(10)]))==5:
                                            text2.set("Sucessfully Marked Attendence")
                                            df["ID"]=df["ID"].apply(lambda x:str(x).zfill(2))
                                            df.to_excel(r".\data\\"+current_month+".xlsx",index=False)
                                    
                                    
                        text1.set(name)
                        
                        
                    if len(img1_encod)==0:
                            print()
                    tag1=0
                    
                if tag1==1:
                    
                    text1.set("")
                    text2.set("")
                    tag5=1
                        
                cv2image= cv2.cvtColor(ha,cv2.COLOR_BGR2RGB)
                
                img = Image.fromarray(cv2image)
                
                

                
                
              
                # Convert image to PhotoImage
                imgtk = ImageTk.PhotoImage(image = img)
                label.imgtk = imgtk
                label.configure(image=imgtk)
                
              
              # Repeat after an interval to capture continiously
            except: pass  
            label.after(20, show_frames)
            
            
            
                
        show_frames()
        
        
        b3=Button(win,text="<-",font=("Helvetica",10,"bold"),bg="#3158d9",fg="#f6f7fb",command=back)
        b3.place(relx=0.05,rely=0.07,anchor="center")
        
        label3=Label(win,font=('helvetica',13,"bold"),textvariable=text1,bg="#3158d9",fg="#f6f7fb",borderwidth=0)
        label3.place(relx=0.5,rely=0.80,anchor="center")
        
        label5=Label(win,font=('helvetica',10,"bold"),textvariable=text2,bg="#3158d9",fg="#f6f7fb",borderwidth=0)
        label5.place(relx=0.5,rely=0.85,anchor="center")
        win.mainloop()
        
    def options():
            
            b1.destroy()
            b4.destroy()
            background_lable1.destroy()
            options1()
            
    filename=PhotoImage(file=resource_path("UI\main bg.png"))
    background_lable1=Label(win,image=filename)
    background_lable1.place(x=0,y=0)
   
    b1=Button(win,text="Start",font=('Times New Roman',14,"bold"),bg="#3158d9",fg="#f6f7fb",width=8,command=start)
    b1.place(relx=0.25,rely=0.60,anchor="center")

    b4=Button(win,text="Options",font=('Times New Roman',14,"bold"),width=8,bg="#3158d9",fg="#f6f7fb",command=options)
    b4.place(relx=0.70,rely=0.60,anchor="center")
    win.mainloop()

   

clear()
